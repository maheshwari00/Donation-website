const mongoose = require("mongoose");

const regSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  contact: {
    type: String,
    required: true,
  },
  mail: {
    type: String,
    required: true,
    unique: true,
  },
  pass: {
    type: String,
    required: true,
  },
  conpass: {
    type: String,
    required: true,
  },
  text: {
    type: String,
    required: false,
  },
});

const Reg = new mongoose.model("Reg", regSchema);
module.exports = Reg;
