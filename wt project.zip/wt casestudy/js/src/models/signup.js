const mongoose = require("mongoose");

const sigSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
  },
  mail: {
    type: String,
    required: true,
    unique: true,
  },
  pas: {
    type: String,
    required: true,
  },
  conpas: {
    type: String,
    required: true,
  },
});

const Signup = new mongoose.model("Signup", sigSchema);
module.exports = Signup;
