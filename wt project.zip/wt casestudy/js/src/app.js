const express = require("express");
const path = require("path");
const app = express();
const hbs = require("hbs");

require("./db/conn");
const Reg = require("./models/reg");
//const Login = require("./models/login");
const Signup = require("./models/signup");
const Donate = require("./models/donate");

const port = process.env.PORT || 3000;

const static = path.join(__dirname, "../public");
const templetes_path = path.join(__dirname, "../templetes/views");
const partials_path = path.join(__dirname, "../templetes/partials");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(express.static(static));
app.set("view engine", "hbs");
app.set("views", templetes_path);
hbs.registerPartials(partials_path);

app.get("/", (req, res) => {
  res.render("index");
});
app.get("/donate", (req, res) => {
  res.render("donate");
});
app.get("/about", (req, res) => {
  res.render("about");
});
app.get("/animalfeeding", (req, res) => {
  res.render("animalfeeding");
});
app.get("/blind", (req, res) => {
  res.render("blind");
});
app.get("/blooddonation", (req, res) => {
  res.render("blooddonation");
});
app.get("/cloths", (req, res) => {
  res.render("cloths");
});
app.get("/contact", (req, res) => {
  res.render("contact");
});
app.get("/disabled", (req, res) => {
  res.render("disabled");
});
app.get("/education", (req, res) => {
  res.render("education");
});
app.get("/food", (req, res) => {
  res.render("food");
});
app.get("/livedata", (req, res) => {
  res.render("livedata");
});
app.get("/oldagedonation", (req, res) => {
  res.render("oldagedonation");
});
app.get("/organdonation", (req, res) => {
  res.render("organdonation");
});
app.get("/register", (req, res) => {
  res.render("register");
});
app.post("/register", async (req, res) => {
  try {
    const pas = req.body.pass;
    const cpas = req.body.conpass;

    if (pas === cpas) {
      const regem = new Reg({
        name: req.body.name,
        contact: req.body.contact,
        mail: req.body.mail,
        pass: req.body.pass,
        conpass: req.body.conpass,
        text: req.body.text,
      });

      const registered = await regem.save();
      res.status(201).render("index");
    } else {
      res.status("passwords are not matching");
    }
  } catch (error) {
    res.status(400).send(error);
  }
});

app.get("/login", (req, res) => {
  res.render("login");
});

app.post("/login", async (req, res) => {
  try {
    const name = req.body.name;
    const mail = req.body.mail;
    const pas = req.body.pas;

    const cemail = await Signup.findOne({
      name: name,
      mail: mail,
    });

    if (cemail.pas === pas) {
      res.status(201).render("index");
    } else {
      res.send("invalid details");
    }
  } catch (error) {
    res.status(400).send(error);
  }
});

app.get("/signup", (req, res) => {
  res.render("signup");
});
app.post("/signup", async (req, res) => {
  try {
    const pas = req.body.pass;
    const cpas = req.body.conpass;

    if (pas === cpas) {
      const signem = new Signup({
        name: req.body.name,
        mail: req.body.mail,
        pas: req.body.pas,
        conpas: req.body.conpas,
      });
      const signed = await signem.save();
      res.status(201).render("index");
    } else {
      res.status("passwords are not matching");
    }
  } catch (error) {
    res.status(400).send(error);
  }
});

app.post("/donate", async (req, res) => {
  try {
    const donem = new Donate({
      fnam: req.body.fnam,
      lnam: req.body.lnam,
      addr: req.body.addr,
      addr2: req.body.addr2,
      city: req.body.city,
      zip: req.body.zip,
      DonateFor: req.body.DonateFor,
      payment: req.body.payment,
      pname: req.body.pname,
      cardn: req.body.cardn,
      cvv: req.body.cvv,
      date: req.body.date,
    });
    const donated = await donem.save();
    res.status(201).render("index");
  } catch (error) {
    res.status(400).send(error);
  }
});

app.listen(port, () => {});
